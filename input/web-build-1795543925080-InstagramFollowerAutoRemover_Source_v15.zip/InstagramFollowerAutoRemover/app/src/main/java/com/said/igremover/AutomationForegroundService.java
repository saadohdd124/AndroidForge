package com.said.igremover;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;
import android.os.SystemClock;

import java.util.HashSet;
import java.util.Set;

/** Keeps a visible, user-controllable session notification while accessibility automation is active. */
public class AutomationForegroundService extends Service {
    public static final String ACTION_START = "com.said.igremover.action.START";
    public static final String ACTION_PAUSE = "com.said.igremover.action.PAUSE";
    public static final String ACTION_RESUME = "com.said.igremover.action.RESUME";
    public static final String ACTION_STOP = "com.said.igremover.action.STOP";
    private static final String CHANNEL_ID = "ig_automation_status";
    private static final int NOTIFICATION_ID = 7401;
    private static long lastRefreshElapsed = 0L;

    public static void start(Context context) {
        Intent intent = new Intent(context, AutomationForegroundService.class).setAction(ACTION_START);
        if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(intent);
        else context.startService(intent);
    }

    public static void stop(Context context) {
        context.stopService(new Intent(context, AutomationForegroundService.class));
    }

    /** Updates the already-created ongoing notification without starting a new background service. */
    public static void refreshNotification(Context context) {
        long now = SystemClock.elapsedRealtime();
        if (now - lastRefreshElapsed < 700) return;
        lastRefreshElapsed = now;
        ensureChannel(context);
        android.content.SharedPreferences prefs = context.getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE);
        if (!prefs.getBoolean(MainActivity.KEY_ENABLED, false)) {
            NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.cancel(NOTIFICATION_ID);
            return;
        }
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) {
            try { nm.notify(NOTIFICATION_ID, buildNotification(context)); }
            catch (SecurityException ignored) { /* Notification permission may be denied. */ }
        }
    }

    private static void ensureChannel(Context context) {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null && nm.getNotificationChannel(CHANNEL_ID) == null) {
                NotificationChannel channel = new NotificationChannel(
                        CHANNEL_ID, "حالة إزالة المتابعين", NotificationManager.IMPORTANCE_LOW);
                channel.setDescription("إشعار دائم بحالة المهمة وأزرار الإيقاف والاستئناف.");
                channel.setShowBadge(false);
                nm.createNotificationChannel(channel);
            }
        }
    }

    @Override public void onCreate() {
        super.onCreate();
        ensureChannel(this);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_START : intent.getAction();
        android.content.SharedPreferences prefs = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE);

        if (ACTION_STOP.equals(action)) {
            prefs.edit().putBoolean(MainActivity.KEY_ENABLED, false)
                    .putBoolean(MainActivity.KEY_PAUSED, false)
                    .putString(MainActivity.KEY_CURRENT, "")
                    .putInt(MainActivity.KEY_PHASE, 0)
                    .putString(MainActivity.KEY_STATUS, "أوقفت المهمة من الإشعار.").apply();
            sendBroadcast(new Intent(MainActivity.ACTION_RESUME_AUTOMATION).setPackage(getPackageName()));
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm != null) nm.cancel(NOTIFICATION_ID);
            stopForeground(true);
            stopSelf(startId);
            return START_NOT_STICKY;
        }

        if (ACTION_PAUSE.equals(action)) {
            prefs.edit().putBoolean(MainActivity.KEY_ENABLED, true)
                    .putBoolean(MainActivity.KEY_PAUSED, true)
                    .putString(MainActivity.KEY_STATUS, "المهمة متوقفة مؤقتاً من الإشعار؛ التقدم محفوظ.").apply();
        } else if (ACTION_RESUME.equals(action)) {
            prefs.edit().putBoolean(MainActivity.KEY_ENABLED, true)
                    .putBoolean(MainActivity.KEY_PAUSED, false)
                    .putString(MainActivity.KEY_STATUS, "استؤنفت المهمة؛ سأتابع عندما تكون واجهة Instagram متاحة.").apply();
            sendBroadcast(new Intent(MainActivity.ACTION_RESUME_AUTOMATION).setPackage(getPackageName()));
        } else if (ACTION_START.equals(action)) {
            sendBroadcast(new Intent(MainActivity.ACTION_RESUME_AUTOMATION).setPackage(getPackageName()));
        }

        if (!prefs.getBoolean(MainActivity.KEY_ENABLED, false)) {
            stopSelf(startId);
            return START_NOT_STICKY;
        }

        Notification notification = buildNotification(this);
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
        refreshNotification(this);
        return START_STICKY;
    }

    private static Notification buildNotification(Context context) {
        ensureChannel(context);
        android.content.SharedPreferences prefs = context.getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE);
        boolean paused = prefs.getBoolean(MainActivity.KEY_PAUSED, false);
        boolean active = prefs.getBoolean(MainActivity.KEY_ENABLED, false);
        Set<String> removed = new HashSet<>();
        Set<String> listDone = prefs.getStringSet(MainActivity.KEY_DONE, null);
        Set<String> categoryDone = prefs.getStringSet(MainActivity.KEY_CATEGORY_DONE, null);
        if (listDone != null) removed.addAll(listDone);
        if (categoryDone != null) removed.addAll(categoryDone);
        Set<String> missing = prefs.getStringSet(MainActivity.KEY_MISSING, null);
        int skipped = missing == null ? 0 : missing.size();
        String status = prefs.getString(MainActivity.KEY_STATUS, "المهمة جاهزة.");
        String state = !active ? "متوقف" : (paused ? "متوقف مؤقتاً" : "يعمل");
        String counts = "طلبات الإزالة المرسلة: " + removed.size() + "  •  المتخطّى: " + skipped;

        Intent open = new Intent(context, MainActivity.class);
        PendingIntent openPi = PendingIntent.getActivity(context, 10, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(context, CHANNEL_ID)
                : new Notification.Builder(context);
        builder.setSmallIcon(android.R.drawable.ic_menu_delete)
                .setContentTitle("مساعد إزالة متابعي إنستغرام")
                .setContentText(counts + "  •  " + state)
                .setStyle(new Notification.BigTextStyle().bigText(counts + "\n" + state + "\n" + status))
                .setContentIntent(openPi)
                .setOngoing(active)
                .setOnlyAlertOnce(true)
                .setShowWhen(false)
                .setCategory(Notification.CATEGORY_SERVICE)
                .setVisibility(Notification.VISIBILITY_PRIVATE);

        if (active) {
            if (paused) {
                builder.addAction(new Notification.Action.Builder(android.R.drawable.ic_media_play,
                        "استئناف", servicePendingIntent(context, ACTION_RESUME, 12)).build());
            } else {
                builder.addAction(new Notification.Action.Builder(android.R.drawable.ic_media_pause,
                        "إيقاف مؤقت", servicePendingIntent(context, ACTION_PAUSE, 11)).build());
            }
            builder.addAction(new Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel,
                    "إيقاف نهائي", servicePendingIntent(context, ACTION_STOP, 13)).build());
        }
        return builder.build();
    }

    private static PendingIntent servicePendingIntent(Context context, String action, int requestCode) {
        Intent intent = new Intent(context, AutomationForegroundService.class).setAction(action);
        return PendingIntent.getService(context, requestCode, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
