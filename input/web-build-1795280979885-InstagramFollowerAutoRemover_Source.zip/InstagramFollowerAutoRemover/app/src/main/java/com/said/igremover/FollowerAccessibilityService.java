package com.said.igremover;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

public class FollowerAccessibilityService extends AccessibilityService {
    private static final String INSTAGRAM = "com.instagram.android";
    private static final int IDLE = 0;
    private static final int WAIT_CONFIRM = 1;
    private static final int WAIT_RESULT = 2;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private Set<String> targets = new HashSet<>();
    private int phase = IDLE;
    private String currentUsername = "";
    private long phaseStartedAt = 0L;
    private boolean scheduled = false;
    private String previousListHash = "";
    private int unchangedScrolls = 0;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        loadTargets();
        setStatus("الخدمة جاهزة. اضغط بدء ثم افتح صفحة المتابعين.");
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || event.getPackageName() == null) return;
        if (!INSTAGRAM.contentEquals(event.getPackageName())) return;
        if (!isEnabled()) return;
        scheduleProcess(650);
    }

    @Override
    public void onInterrupt() {
        stopAutomation("أوقف أندرويد خدمة إمكانية الوصول؛ أعد تفعيلها ثم ابدأ من جديد.");
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    private void loadTargets() {
        if (!targets.isEmpty()) return;
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(getAssets().open("followers_2021_2022.txt")))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String username = normalizeUsername(line);
                if (!username.isEmpty()) targets.add(username);
            }
        } catch (Exception e) {
            stopAutomation("تعذّرت قراءة قائمة أسماء المستخدمين المضمّنة.");
        }
    }

    private boolean isEnabled() {
        return getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
                .getBoolean(MainActivity.KEY_ENABLED, false);
    }

    private void scheduleProcess(long delayMs) {
        if (scheduled) return;
        scheduled = true;
        handler.postDelayed(() -> {
            scheduled = false;
            processActiveScreen();
        }, delayMs);
    }

    private void processActiveScreen() {
        if (!isEnabled()) {
            phase = IDLE;
            currentUsername = "";
            return;
        }

        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null || root.getPackageName() == null || !INSTAGRAM.contentEquals(root.getPackageName())) return;

        String screenText = collectText(root).toLowerCase(Locale.ROOT);
        if (looksLikeSecurityChallenge(screenText)) {
            stopAutomation("توقفت لحماية الحساب: ظهرت شاشة تحقق أو تحذير أمني من إنستغرام.");
            return;
        }
        if (!isFollowersScreen(screenText)) {
            setStatus("جاهز وينتظر صفحة Followers / المتابعون. انتقل إليها داخل إنستغرام.");
            return;
        }

        if (phase == WAIT_CONFIRM) {
            handleConfirmation(root, screenText);
            return;
        }
        if (phase == WAIT_RESULT) {
            handleRemovalResult(root, screenText);
            return;
        }

        Candidate candidate = findVisibleTarget(root);
        if (candidate != null) {
            AccessibilityNodeInfo removeButton = findRemoveButtonNear(candidate.node);
            if (removeButton == null) {
                stopAutomation("وجدت @" + candidate.username + " لكن لم أتعرف بأمان على زر Remove بجانبه. أوقفت العمل دون الضغط على عنصر آخر.");
                return;
            }
            boolean clicked = safeClick(removeButton);
            if (!clicked) {
                stopAutomation("تعذّر الضغط على زر Remove للحساب @" + candidate.username + ".");
                return;
            }
            currentUsername = candidate.username;
            phase = WAIT_CONFIRM;
            phaseStartedAt = System.currentTimeMillis();
            setCurrent(currentUsername);
            setStatus("طلب تأكيد إزالة @" + currentUsername + " ...");
            scheduleProcess(900);
            return;
        }

        String hash = Integer.toHexString(screenText.hashCode());
        if (hash.equals(previousListHash)) unchangedScrolls++; else unchangedScrolls = 0;
        previousListHash = hash;
        if (unchangedScrolls >= 3) {
            stopAutomation("لم أعد أرى حساباً مستهدفاً بعد محاولات التمرير. أوقفت العمل؛ راجع المتبقي في التطبيق.");
            return;
        }
        if (scrollList(root)) {
            setStatus("أبحث في قائمة المتابعين عن الأسماء المستهدفة...");
            scheduleProcess(1600);
        } else {
            stopAutomation("لم أتمكن من تمرير قائمة المتابعين. بقيت أسماء لم تتم معالجتها.");
        }
    }

    private void handleConfirmation(AccessibilityNodeInfo root, String text) {
        if (isConfirmationDialog(text)) {
            AccessibilityNodeInfo confirm = findRemoveButtonInTree(root);
            if (confirm == null || !safeClick(confirm)) {
                stopAutomation("ظهرت نافذة التأكيد لكن لم أتعرف بأمان على زر التأكيد. لم أتابع.");
                return;
            }
            phase = WAIT_RESULT;
            phaseStartedAt = System.currentTimeMillis();
            setStatus("تم تأكيد إزالة @" + currentUsername + "؛ أتحقق من اختفائه من القائمة.");
            scheduleProcess(1800);
            return;
        }
        if (System.currentTimeMillis() - phaseStartedAt > 10000) {
            stopAutomation("لم تظهر نافذة تأكيد الحذف المتوقعة للحساب @" + currentUsername + ". أوقفت العمل.");
            return;
        }
        scheduleProcess(800);
    }

    private void handleRemovalResult(AccessibilityNodeInfo root, String text) {
        if (isConfirmationDialog(text)) {
            if (System.currentTimeMillis() - phaseStartedAt > 10000) {
                stopAutomation("لم تختفِ نافذة التأكيد بعد الضغط؛ أوقفت العمل.");
            } else {
                scheduleProcess(900);
            }
            return;
        }
        if (!containsUsername(root, currentUsername)) {
            recordDone(currentUsername);
            phase = IDLE;
            currentUsername = "";
            setCurrent("");
            int totalDone = getDoneSet().size();
            setStatus("اكتملت إزالة الحساب " + totalDone + " من " + targets.size() + ". أتابع تلقائياً.");
            previousListHash = "";
            unchangedScrolls = 0;
            if (totalDone % 40 == 0) {
                setStatus("تمت إزالة " + totalDone + " حساباً. استراحة احترازية لمدة دقيقتين قبل المتابعة.");
                scheduleProcess(120000);
            } else {
                scheduleProcess(2700);
            }
            return;
        }
        if (System.currentTimeMillis() - phaseStartedAt > 12000) {
            stopAutomation("لم أستطع التحقق من إزالة @" + currentUsername + ". أوقفت العمل دون إعادة المحاولة تلقائياً.");
            return;
        }
        scheduleProcess(1000);
    }

    private Candidate findVisibleTarget(AccessibilityNodeInfo root) {
        Set<String> done = getDoneSet();
        Set<String> missing = getMissingSet();
        ArrayDeque<AccessibilityNodeInfo> queue = new ArrayDeque<>();
        queue.add(root);
        while (!queue.isEmpty()) {
            AccessibilityNodeInfo node = queue.removeFirst();
            String handle = usernameFromNode(node);
            if (!handle.isEmpty() && targets.contains(handle) && !done.contains(handle) && !missing.contains(handle)) {
                return new Candidate(handle, node);
            }
            for (int i = 0; i < node.getChildCount(); i++) {
                AccessibilityNodeInfo child = node.getChild(i);
                if (child != null) queue.addLast(child);
            }
        }
        return null;
    }

    private String usernameFromNode(AccessibilityNodeInfo node) {
        CharSequence text = node.getText();
        if (text == null) text = node.getContentDescription();
        if (text == null) return "";
        String raw = text.toString().trim();
        if (raw.startsWith("@")) raw = raw.substring(1);
        if (targets.contains(raw.toLowerCase(Locale.ROOT))) return raw.toLowerCase(Locale.ROOT);
        String[] lines = raw.split("[\\r\\n\\s]+", 3);
        if (lines.length > 0) {
            String first = lines[0].replaceFirst("^@", "").toLowerCase(Locale.ROOT);
            if (targets.contains(first)) return first;
        }
        return "";
    }

    private AccessibilityNodeInfo findRemoveButtonNear(AccessibilityNodeInfo userNode) {
        AccessibilityNodeInfo ancestor = userNode;
        for (int level = 0; level < 7 && ancestor != null; level++) {
            AccessibilityNodeInfo button = findRemoveButtonInTree(ancestor);
            if (button != null && button != userNode) return button;
            ancestor = ancestor.getParent();
        }
        return null;
    }

    private AccessibilityNodeInfo findRemoveButtonInTree(AccessibilityNodeInfo root) {
        ArrayDeque<AccessibilityNodeInfo> queue = new ArrayDeque<>();
        queue.add(root);
        while (!queue.isEmpty()) {
            AccessibilityNodeInfo node = queue.removeFirst();
            if (isRemoveLabel(node.getText()) || isRemoveLabel(node.getContentDescription())) {
                if (node.isClickable()) return node;
                AccessibilityNodeInfo parent = node.getParent();
                for (int i = 0; i < 2 && parent != null && parent != root; i++) {
                    if (parent.isClickable()) return parent;
                    parent = parent.getParent();
                }
            }
            for (int i = 0; i < node.getChildCount(); i++) {
                AccessibilityNodeInfo child = node.getChild(i);
                if (child != null) queue.addLast(child);
            }
        }
        return null;
    }

    private boolean isRemoveLabel(CharSequence value) {
        if (value == null) return false;
        String s = value.toString().trim().toLowerCase(Locale.ROOT);
        return s.equals("remove") || s.equals("remove follower") || s.equals("remove follower?")
                || s.equals("إزالة") || s.equals("حذف") || s.equals("إزالة المتابع")
                || s.equals("supprimer") || s.equals("retirer") || s.equals("supprimer l’abonné")
                || s.equals("supprimer l'abonné") || s.equals("retirer l’abonné");
    }

    private boolean isConfirmationDialog(String text) {
        return text.contains("remove follower") || text.contains("remove this follower")
                || text.contains("remove @") || text.contains("إزالة المتابع")
                || text.contains("هل تريد إزالة") || text.contains("supprimer l’abonné")
                || text.contains("supprimer l'abonné") || text.contains("retirer cet abonné");
    }

    private boolean isFollowersScreen(String text) {
        return text.contains("followers") || text.contains("المتابعون") || text.contains("المتابعين")
                || text.contains("abonnés") || text.contains("abonnees") || text.contains("seguidores");
    }

    private boolean looksLikeSecurityChallenge(String text) {
        return text.contains("captcha") || text.contains("challenge") || text.contains("suspicious activity")
                || text.contains("unusual activity") || text.contains("confirm it's you")
                || text.contains("confirm your account") || text.contains("try again later")
                || text.contains("we restrict certain activity") || text.contains("too many requests")
                || text.contains("نشاط غير معتاد") || text.contains("أكد هويتك")
                || text.contains("تحقق من هويتك") || text.contains("نشاط مريب")
                || text.contains("activité suspecte") || text.contains("confirmez votre identité");
    }

    private String collectText(AccessibilityNodeInfo root) {
        StringBuilder builder = new StringBuilder();
        ArrayDeque<AccessibilityNodeInfo> queue = new ArrayDeque<>();
        queue.add(root);
        int visited = 0;
        while (!queue.isEmpty() && visited < 3000) {
            AccessibilityNodeInfo node = queue.removeFirst();
            visited++;
            if (node.getText() != null) builder.append(node.getText()).append(' ');
            if (node.getContentDescription() != null) builder.append(node.getContentDescription()).append(' ');
            for (int i = 0; i < node.getChildCount(); i++) {
                AccessibilityNodeInfo child = node.getChild(i);
                if (child != null) queue.addLast(child);
            }
        }
        return builder.toString();
    }

    private boolean containsUsername(AccessibilityNodeInfo root, String username) {
        ArrayDeque<AccessibilityNodeInfo> queue = new ArrayDeque<>();
        queue.add(root);
        while (!queue.isEmpty()) {
            AccessibilityNodeInfo node = queue.removeFirst();
            if (username.equals(usernameFromNode(node))) return true;
            CharSequence text = node.getText();
            CharSequence desc = node.getContentDescription();
            if (matchesRawUsername(text, username) || matchesRawUsername(desc, username)) return true;
            for (int i = 0; i < node.getChildCount(); i++) {
                AccessibilityNodeInfo child = node.getChild(i);
                if (child != null) queue.addLast(child);
            }
        }
        return false;
    }

    private boolean matchesRawUsername(CharSequence value, String username) {
        if (value == null) return false;
        String s = value.toString().trim().toLowerCase(Locale.ROOT).replaceFirst("^@", "");
        return s.equals(username);
    }

    private boolean scrollList(AccessibilityNodeInfo root) {
        AccessibilityNodeInfo scrollable = findScrollable(root);
        if (scrollable != null && scrollable.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)) return true;
        // Fallback swipe only while the app is positively identified as the Followers screen.
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        float x = dm.widthPixels * 0.50f;
        float y1 = dm.heightPixels * 0.78f;
        float y2 = dm.heightPixels * 0.34f;
        Path path = new Path();
        path.moveTo(x, y1);
        path.lineTo(x, y2);
        GestureDescription.StrokeDescription stroke = new GestureDescription.StrokeDescription(path, 0, 420);
        return dispatchGesture(new GestureDescription.Builder().addStroke(stroke).build(), null, null);
    }

    private AccessibilityNodeInfo findScrollable(AccessibilityNodeInfo root) {
        ArrayDeque<AccessibilityNodeInfo> queue = new ArrayDeque<>();
        queue.add(root);
        while (!queue.isEmpty()) {
            AccessibilityNodeInfo node = queue.removeFirst();
            if (node.isScrollable()) return node;
            for (int i = 0; i < node.getChildCount(); i++) {
                AccessibilityNodeInfo child = node.getChild(i);
                if (child != null) queue.addLast(child);
            }
        }
        return null;
    }

    private boolean safeClick(AccessibilityNodeInfo node) {
        if (node == null) return false;
        if (node.isClickable()) return node.performAction(AccessibilityNodeInfo.ACTION_CLICK);
        return false;
    }

    private void recordDone(String username) {
        Set<String> done = getDoneSet();
        done.add(username);
        getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).edit()
                .putStringSet(MainActivity.KEY_DONE, done).apply();
    }

    private Set<String> getDoneSet() {
        Set<String> current = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
                .getStringSet(MainActivity.KEY_DONE, new HashSet<>());
        return new HashSet<>(current == null ? new HashSet<>() : current);
    }

    private Set<String> getMissingSet() {
        Set<String> current = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
                .getStringSet(MainActivity.KEY_MISSING, new HashSet<>());
        return new HashSet<>(current == null ? new HashSet<>() : current);
    }

    private void setCurrent(String username) {
        getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).edit()
                .putString(MainActivity.KEY_CURRENT, username).apply();
    }

    private void setStatus(String status) {
        getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).edit()
                .putString(MainActivity.KEY_STATUS, status).apply();
    }

    private void stopAutomation(String reason) {
        getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).edit()
                .putBoolean(MainActivity.KEY_ENABLED, false)
                .putString(MainActivity.KEY_STATUS, reason)
                .apply();
        phase = IDLE;
        currentUsername = "";
        setCurrent("");
        scheduled = false;
        handler.removeCallbacksAndMessages(null);
    }

    private String normalizeUsername(String value) {
        if (value == null) return "";
        return value.trim().replaceFirst("^@", "").toLowerCase(Locale.ROOT);
    }

    private static class Candidate {
        final String username;
        final AccessibilityNodeInfo node;
        Candidate(String username, AccessibilityNodeInfo node) {
            this.username = username;
            this.node = node;
        }
    }
}
