package com.said.igremover;

import android.accessibilityservice.AccessibilityService;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Searches for each target username on Instagram's Followers screen, verifies the exact
 * result row, clicks that row's remove control, confirms the dialog, and verifies that the
 * result disappeared. It deliberately stops whenever the UI cannot be identified safely.
 */
public class FollowerAccessibilityService extends AccessibilityService {
    private static final String INSTAGRAM = "com.instagram.android";

    private static final int IDLE = 0;
    private static final int WAIT_SEARCH_RESULT = 1;
    private static final int WAIT_CONFIRMATION = 2;
    private static final int WAIT_REMOVAL_RESULT = 3;

    private static final long SEARCH_TIMEOUT_MS = 15000L;
    private static final long CONFIRM_TIMEOUT_MS = 10000L;
    private static final long REMOVE_TIMEOUT_MS = 15000L;
    private static final int ACTIONS_BETWEEN_BREAKS = 25;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final List<String> targetOrder = new ArrayList<>();
    private final Set<String> targets = new HashSet<>();

    private int phase = IDLE;
    private String currentUsername = "";
    private long phaseStartedAt = 0L;
    private boolean scheduled = false;
    private int missingResultObservations = 0;
    private int actionsSinceBreak = 0;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        loadTargets();
        setStatus("الخدمة جاهزة. افتح صفحة المتابعين داخل إنستغرام.");
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || event.getPackageName() == null) return;
        if (!INSTAGRAM.contentEquals(event.getPackageName())) return;
        if (!isEnabled()) return;
        scheduleProcess(650);
    }

    @Override
    public void onInterrupt() {
        stopAutomation("أوقف أندرويد خدمة إمكانية الوصول؛ أعد تفعيلها ثم ابدأ من جديد.");
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    private void loadTargets() {
        if (!targetOrder.isEmpty()) return;
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(getAssets().open("followers_2021_2022.txt")))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String username = normalizeUsername(line);
                if (!username.isEmpty() && targets.add(username)) {
                    targetOrder.add(username);
                }
            }
            if (targetOrder.isEmpty()) {
                stopAutomation("قائمة الحسابات المستهدفة فارغة.");
            }
        } catch (Exception e) {
            stopAutomation("تعذّرت قراءة قائمة أسماء المستخدمين المضمّنة.");
        }
    }

    private boolean isEnabled() {
        return getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
                .getBoolean(MainActivity.KEY_ENABLED, false);
    }

    private void scheduleProcess(long delayMs) {
        if (scheduled) return;
        scheduled = true;
        handler.postDelayed(() -> {
            scheduled = false;
            processActiveScreen();
        }, delayMs);
    }

    private void processActiveScreen() {
        if (!isEnabled()) {
            phase = IDLE;
            currentUsername = "";
            return;
        }

        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null || root.getPackageName() == null
                || !INSTAGRAM.contentEquals(root.getPackageName())) {
            return;
        }

        String screenText = collectText(root).toLowerCase(Locale.ROOT);
        if (looksLikeSecurityChallenge(screenText)) {
            stopAutomation("توقفت لحماية الحساب: ظهرت شاشة تحقق أو تحذير أمني من إنستغرام.");
            return;
        }

        if (phase == WAIT_CONFIRMATION) {
            handleConfirmation(root, screenText);
            return;
        }
        if (phase == WAIT_REMOVAL_RESULT) {
            handleRemovalResult(root, screenText);
            return;
        }
        if (!isFollowersScreen(screenText)) {
            setStatus("بانتظار صفحة Followers / المتابعون. افتح صفحة المتابعين واتركها ظاهرة.");
            return;
        }
        if (phase == WAIT_SEARCH_RESULT) {
            handleSearchResult(root, screenText);
            return;
        }

        beginNextSearch(root);
    }

    /** Starts the next search by replacing the search field's current value. */
    private void beginNextSearch(AccessibilityNodeInfo root) {
        String next = getNextPendingUsername();
        if (next == null) {
            stopAutomation("انتهت القائمة: لم تبقَ حسابات مستهدفة غير معالجة.");
            return;
        }

        AccessibilityNodeInfo searchField = findSearchField(root);
        if (searchField == null) {
            stopAutomation("لم أتعرف بأمان على خانة Search username or display name. لم أضغط على أي حساب.");
            return;
        }

        currentUsername = next;
        setCurrent(currentUsername);
        if (!setSearchText(searchField, currentUsername)) {
            stopAutomation("وجدت خانة البحث، لكن تعذّر إدخال @" + currentUsername + " فيها. لم أتابع.");
            return;
        }

        phase = WAIT_SEARCH_RESULT;
        phaseStartedAt = System.currentTimeMillis();
        setStatus("أبحث عن @" + currentUsername + " وأنتظر نتيجة مطابقة تماماً...");
        scheduleProcess(1300);
    }

    private void handleSearchResult(AccessibilityNodeInfo root, String text) {
        AccessibilityNodeInfo usernameNode = findExactUsernameNode(root, currentUsername);
        if (usernameNode != null) {
            Rect usernameBounds = new Rect();
            usernameNode.getBoundsInScreen(usernameBounds);
            AccessibilityNodeInfo removeControl = findRemoveControlForRow(root, usernameNode, usernameBounds);
            if (removeControl == null) {
                stopAutomation("ظهرت نتيجة @" + currentUsername
                        + "، لكن لم أستطع تحديد علامة × الخاصة بصفّها بأمان. لم أضغط على عنصر آخر.");
                return;
            }
            if (!safeClick(removeControl)) {
                stopAutomation("تعذّر الضغط على علامة × بجانب @" + currentUsername + ".");
                return;
            }
            phase = WAIT_CONFIRMATION;
            phaseStartedAt = System.currentTimeMillis();
            setStatus("تم تحديد نتيجة @" + currentUsername + " المطابقة؛ أنتظر نافذة تأكيد Remove follower.");
            scheduleProcess(900);
            return;
        }

        if (isNoResultsMessage(text)) {
            skipMissingAccount(root, "لم يعثر Instagram على نتيجة لهذا الاسم.");
            return;
        }

        if (System.currentTimeMillis() - phaseStartedAt > SEARCH_TIMEOUT_MS) {
            // Instagram sometimes exposes an empty result state without readable
            // "No results" text. After the full search timeout, skip this username
            // instead of stopping the entire run. No removal action is attempted.
            skipMissingAccount(root,
                    "انتهت مهلة البحث دون ظهور حساب مطابق؛ تم تخطي الاسم دون محاولة حذفه.");
            return;
        }
        scheduleProcess(900);
    }


    /** Marks the current target as missing and advances to the next pending username. */
    private void skipMissingAccount(AccessibilityNodeInfo root, String reason) {
        if (currentUsername == null || currentUsername.isEmpty()) {
            stopAutomation("تعذّر تحديد الحساب الحالي أثناء التخطي؛ أوقفت العملية بأمان.");
            return;
        }

        String skipped = currentUsername;
        recordMissing(skipped);
        currentUsername = "";
        setCurrent("");
        phase = IDLE;
        clearSearchField(root);
        setStatus(reason + " الحساب: @" + skipped
                + ". تم تسجيله ضمن الحسابات التي تم تخطيها، والانتقال إلى الحساب التالي.");
        scheduleProcess(900);
    }

    private void handleConfirmation(AccessibilityNodeInfo root, String text) {
        if (isConfirmationDialog(text)) {
            AccessibilityNodeInfo confirm = findConfirmationAction(root);
            if (confirm == null || !safeClick(confirm)) {
                stopAutomation("ظهرت نافذة تأكيد إزالة @" + currentUsername
                        + "، لكن لم أتعرف على زر التأكيد بدقة. لم أتابع.");
                return;
            }
            phase = WAIT_REMOVAL_RESULT;
            phaseStartedAt = System.currentTimeMillis();
            missingResultObservations = 0;
            setStatus("ضغطت تأكيد إزالة @" + currentUsername + "؛ أتحقق من اختفاء نتيجة البحث.");
            scheduleProcess(1800);
            return;
        }

        if (System.currentTimeMillis() - phaseStartedAt > CONFIRM_TIMEOUT_MS) {
            stopAutomation("لم تظهر نافذة تأكيد الإزالة المتوقعة للحساب @" + currentUsername
                    + ". أوقفت العمل دون إجراء إضافي.");
            return;
        }
        scheduleProcess(800);
    }

    private void handleRemovalResult(AccessibilityNodeInfo root, String text) {
        if (isConfirmationDialog(text)) {
            if (System.currentTimeMillis() - phaseStartedAt > CONFIRM_TIMEOUT_MS) {
                stopAutomation("بقيت نافذة التأكيد ظاهرة بعد الضغط؛ أوقفت العمل.");
            } else {
                scheduleProcess(900);
            }
            return;
        }

        AccessibilityNodeInfo remainingResult = findExactUsernameNode(root, currentUsername);
        if (remainingResult == null || isNoResultsMessage(text)) {
            missingResultObservations++;
            if (missingResultObservations >= 2) {
                String removed = currentUsername;
                recordDone(removed);
                currentUsername = "";
                setCurrent("");
                phase = IDLE;
                actionsSinceBreak++;
                clearSearchField(root);
                int totalDone = getDoneSet().size();
                setStatus("تم التحقق من اختفاء @" + removed + ". الإجمالي المؤكد: "
                        + totalDone + " من " + targetOrder.size() + ".");
                if (actionsSinceBreak >= ACTIONS_BETWEEN_BREAKS) {
                    actionsSinceBreak = 0;
                    setStatus("تم التحقق من إزالة " + totalDone
                            + " حساباً. توقّف احترازي لمدة دقيقتين قبل متابعة القائمة.");
                    scheduleProcess(120000);
                } else {
                    scheduleProcess(1400);
                }
                return;
            }
        } else {
            missingResultObservations = 0;
        }

        if (System.currentTimeMillis() - phaseStartedAt > REMOVE_TIMEOUT_MS) {
            stopAutomation("لم أستطع التحقق من اختفاء @" + currentUsername
                    + " بعد التأكيد. أوقفت العمل ولم أسجله كمحذوف.");
            return;
        }
        scheduleProcess(1000);
    }

    private String getNextPendingUsername() {
        Set<String> done = getDoneSet();
        Set<String> missing = getMissingSet();
        for (String username : targetOrder) {
            if (!done.contains(username) && !missing.contains(username)) return username;
        }
        return null;
    }

    private AccessibilityNodeInfo findSearchField(AccessibilityNodeInfo root) {
        ArrayDeque<AccessibilityNodeInfo> queue = new ArrayDeque<>();
        queue.add(root);
        AccessibilityNodeInfo best = null;
        int bestScore = Integer.MIN_VALUE;
        int screenHeight = getResources().getDisplayMetrics().heightPixels;

        while (!queue.isEmpty()) {
            AccessibilityNodeInfo node = queue.removeFirst();
            CharSequence className = node.getClassName();
            String classValue = className == null ? "" : className.toString().toLowerCase(Locale.ROOT);
            CharSequence hintValue = node.getHintText();
            String hint = hintValue == null ? "" : hintValue.toString().toLowerCase(Locale.ROOT);
            CharSequence viewIdValue = node.getViewIdResourceName();
            String viewId = viewIdValue == null ? "" : viewIdValue.toString().toLowerCase(Locale.ROOT);

            boolean editable = node.isEditable() || classValue.contains("edittext");
            boolean searchNamed = hint.contains("search") || hint.contains("username")
                    || hint.contains("بحث") || viewId.contains("search");
            if (editable && node.isVisibleToUser()) {
                Rect bounds = new Rect();
                node.getBoundsInScreen(bounds);
                int score = 0;
                if (searchNamed) score += 100;
                if (bounds.top < screenHeight * 0.45f) score += 20;
                if (bounds.width() > 0 && bounds.height() > 0) score += 5;
                if (score > bestScore) {
                    bestScore = score;
                    best = node;
                }
            }

            for (int i = 0; i < node.getChildCount(); i++) {
                AccessibilityNodeInfo child = node.getChild(i);
                if (child != null) queue.addLast(child);
            }
        }
        return best;
    }

    private boolean setSearchText(AccessibilityNodeInfo field, String value) {
        if (field == null) return false;
        field.performAction(AccessibilityNodeInfo.ACTION_CLICK);
        field.performAction(AccessibilityNodeInfo.ACTION_FOCUS);
        Bundle args = new Bundle();
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, value);
        return field.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args);
    }

    private boolean clearSearchField(AccessibilityNodeInfo root) {
        AccessibilityNodeInfo field = findSearchField(root);
        return field != null && setSearchText(field, "");
    }

    private AccessibilityNodeInfo findExactUsernameNode(AccessibilityNodeInfo root, String username) {
        if (root == null || username == null || username.isEmpty()) return null;
        ArrayDeque<AccessibilityNodeInfo> queue = new ArrayDeque<>();
        queue.add(root);
        while (!queue.isEmpty()) {
            AccessibilityNodeInfo node = queue.removeFirst();
            if (!node.isEditable() && node.isVisibleToUser()
                    && (isExactUsernameValue(node.getText(), username)
                    || isExactUsernameValue(node.getContentDescription(), username))) {
                Rect bounds = new Rect();
                node.getBoundsInScreen(bounds);
                if (!bounds.isEmpty()) return node;
            }
            for (int i = 0; i < node.getChildCount(); i++) {
                AccessibilityNodeInfo child = node.getChild(i);
                if (child != null) queue.addLast(child);
            }
        }
        return null;
    }

    private boolean isExactUsernameValue(CharSequence value, String username) {
        if (value == null) return false;
        String raw = value.toString().trim().toLowerCase(Locale.ROOT).replaceFirst("^@", "");
        if (raw.equals(username)) return true;
        String[] lines = raw.split("[\\r\\n\\s]+", 3);
        return lines.length > 0 && lines[0].replaceFirst("^@", "").equals(username);
    }

    /**
     * Prefer an explicitly labelled Remove follower control. If Instagram exposes only an
     * unlabeled X icon, accept only a small clickable control at the far-right of the exact
     * result row's vertical band. Never click a broad row or the Message button.
     */
    private AccessibilityNodeInfo findRemoveControlForRow(
            AccessibilityNodeInfo root, AccessibilityNodeInfo usernameNode, Rect usernameBounds) {
        ArrayDeque<AccessibilityNodeInfo> queue = new ArrayDeque<>();
        queue.add(root);
        AccessibilityNodeInfo labelled = null;
        AccessibilityNodeInfo rightmostX = null;
        int bestLabelScore = Integer.MAX_VALUE;
        int bestXScore = Integer.MAX_VALUE;

        int screenWidth = getResources().getDisplayMetrics().widthPixels;
        int rowTolerance = dp(48);
        int maxControlSize = dp(110);

        while (!queue.isEmpty()) {
            AccessibilityNodeInfo node = queue.removeFirst();
            if (node.isClickable() && node.isVisibleToUser()) {
                Rect bounds = new Rect();
                node.getBoundsInScreen(bounds);
                if (!bounds.isEmpty()) {
                    int yDistance = Math.abs(bounds.centerY() - usernameBounds.centerY());
                    boolean sameRow = yDistance <= rowTolerance;
                    boolean rightOfUsername = bounds.centerX() > usernameBounds.centerX() + dp(55);
                    boolean compact = bounds.width() <= maxControlSize && bounds.height() <= maxControlSize;

                    if (sameRow && rightOfUsername && isRemoveLabel(node.getText(), node.getContentDescription())) {
                        int score = yDistance;
                        if (score < bestLabelScore) {
                            bestLabelScore = score;
                            labelled = node;
                        }
                    }

                    boolean atFarRight = bounds.centerX() >= screenWidth * 0.78f;
                    if (sameRow && rightOfUsername && compact && atFarRight) {
                        int score = yDistance * 10 + Math.max(0, screenWidth - bounds.centerX()) / 10;
                        if (score < bestXScore) {
                            bestXScore = score;
                            rightmostX = node;
                        }
                    }
                }
            }
            for (int i = 0; i < node.getChildCount(); i++) {
                AccessibilityNodeInfo child = node.getChild(i);
                if (child != null) queue.addLast(child);
            }
        }
        return labelled != null ? labelled : rightmostX;
    }

    private boolean isRemoveLabel(CharSequence text, CharSequence description) {
        return isRemoveLabelValue(text) || isRemoveLabelValue(description);
    }

    private boolean isRemoveLabelValue(CharSequence value) {
        if (value == null) return false;
        String s = value.toString().trim().toLowerCase(Locale.ROOT);
        return s.equals("remove") || s.equals("remove follower") || s.equals("remove follower?")
                || s.startsWith("remove follower ") || s.equals("إزالة") || s.equals("حذف")
                || s.equals("إزالة المتابع") || s.equals("supprimer") || s.equals("retirer")
                || s.equals("supprimer l’abonné") || s.equals("supprimer l'abonné")
                || s.equals("retirer l’abonné");
    }

    private boolean isConfirmationDialog(String text) {
        boolean removeFollower = text.contains("remove follower")
                || text.contains("remove this follower")
                || text.contains("إزالة المتابع")
                || text.contains("supprimer l’abonné")
                || text.contains("supprimer l'abonné");
        boolean hasQuestionOrCancel = text.contains("remove follower?")
                || text.contains("are you sure") || text.contains("cancel")
                || text.contains("إلغاء") || text.contains("هل تريد إزالة")
                || text.contains("retour");
        return removeFollower && hasQuestionOrCancel;
    }

    private AccessibilityNodeInfo findConfirmationAction(AccessibilityNodeInfo root) {
        ArrayDeque<AccessibilityNodeInfo> queue = new ArrayDeque<>();
        queue.add(root);
        while (!queue.isEmpty()) {
            AccessibilityNodeInfo node = queue.removeFirst();
            if (node.isVisibleToUser()
                    && isConfirmationActionLabel(node.getText(), node.getContentDescription())) {
                if (node.isClickable()) return node;
                AccessibilityNodeInfo parent = node.getParent();
                for (int level = 0; level < 2 && parent != null; level++) {
                    if (parent.isClickable() && parent.isVisibleToUser()) return parent;
                    parent = parent.getParent();
                }
            }
            for (int i = 0; i < node.getChildCount(); i++) {
                AccessibilityNodeInfo child = node.getChild(i);
                if (child != null) queue.addLast(child);
            }
        }
        return null;
    }

    private boolean isConfirmationActionLabel(CharSequence text, CharSequence description) {
        return isConfirmationActionValue(text) || isConfirmationActionValue(description);
    }

    private boolean isConfirmationActionValue(CharSequence value) {
        if (value == null) return false;
        String s = value.toString().trim().toLowerCase(Locale.ROOT);
        return s.equals("remove") || s.equals("إزالة") || s.equals("حذف")
                || s.equals("supprimer") || s.equals("retirer");
    }

    private boolean isNoResultsMessage(String text) {
        return text.contains("no results") || text.contains("no users found")
                || text.contains("no people found") || text.contains("لم يتم العثور على نتائج")
                || text.contains("لا توجد نتائج") || text.contains("لم يتم العثور على أي")
                || text.contains("aucun résultat") || text.contains("aucun resultat")
                || text.contains("sin resultados");
    }

    private boolean isFollowersScreen(String text) {
        return text.contains("followers") || text.contains("المتابعون")
                || text.contains("المتابعين") || text.contains("abonnés")
                || text.contains("abonnees") || text.contains("seguidores");
    }

    private boolean looksLikeSecurityChallenge(String text) {
        return text.contains("captcha") || text.contains("challenge")
                || text.contains("suspicious activity") || text.contains("unusual activity")
                || text.contains("confirm it's you") || text.contains("confirm your account")
                || text.contains("try again later") || text.contains("we restrict certain activity")
                || text.contains("too many requests") || text.contains("نشاط غير معتاد")
                || text.contains("أكد هويتك") || text.contains("تحقق من هويتك")
                || text.contains("نشاط مريب") || text.contains("activité suspecte")
                || text.contains("confirmez votre identité");
    }

    private String collectText(AccessibilityNodeInfo root) {
        StringBuilder builder = new StringBuilder();
        ArrayDeque<AccessibilityNodeInfo> queue = new ArrayDeque<>();
        queue.add(root);
        int visited = 0;
        while (!queue.isEmpty() && visited < 4000) {
            AccessibilityNodeInfo node = queue.removeFirst();
            visited++;
            if (node.getText() != null) builder.append(node.getText()).append(' ');
            if (node.getContentDescription() != null) builder.append(node.getContentDescription()).append(' ');
            if (node.getHintText() != null) builder.append(node.getHintText()).append(' ');
            for (int i = 0; i < node.getChildCount(); i++) {
                AccessibilityNodeInfo child = node.getChild(i);
                if (child != null) queue.addLast(child);
            }
        }
        return builder.toString();
    }

    private boolean safeClick(AccessibilityNodeInfo node) {
        return node != null && node.isClickable()
                && node.performAction(AccessibilityNodeInfo.ACTION_CLICK);
    }

    private void recordDone(String username) {
        Set<String> done = getDoneSet();
        done.add(username);
        getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).edit()
                .putStringSet(MainActivity.KEY_DONE, done).apply();
    }

    private void recordMissing(String username) {
        Set<String> missing = getMissingSet();
        missing.add(username);
        getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).edit()
                .putStringSet(MainActivity.KEY_MISSING, missing).apply();
    }

    private Set<String> getDoneSet() {
        Set<String> current = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
                .getStringSet(MainActivity.KEY_DONE, new HashSet<>());
        return new HashSet<>(current == null ? new HashSet<>() : current);
    }

    private Set<String> getMissingSet() {
        Set<String> current = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
                .getStringSet(MainActivity.KEY_MISSING, new HashSet<>());
        return new HashSet<>(current == null ? new HashSet<>() : current);
    }

    private void setCurrent(String username) {
        getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).edit()
                .putString(MainActivity.KEY_CURRENT, username).apply();
    }

    private void setStatus(String status) {
        getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).edit()
                .putString(MainActivity.KEY_STATUS, status).apply();
    }

    private void stopAutomation(String reason) {
        getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).edit()
                .putBoolean(MainActivity.KEY_ENABLED, false)
                .putString(MainActivity.KEY_STATUS, reason)
                .apply();
        phase = IDLE;
        currentUsername = "";
        setCurrent("");
        scheduled = false;
        handler.removeCallbacksAndMessages(null);
    }

    private String normalizeUsername(String value) {
        if (value == null) return "";
        return value.trim().replaceFirst("^@", "").toLowerCase(Locale.ROOT);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
