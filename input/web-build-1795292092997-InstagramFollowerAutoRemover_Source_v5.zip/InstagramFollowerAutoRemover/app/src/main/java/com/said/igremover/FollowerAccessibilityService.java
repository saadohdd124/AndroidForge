package com.said.igremover;

import android.accessibilityservice.AccessibilityService;
import android.graphics.Rect;
import android.graphics.Path;
import android.accessibilityservice.GestureDescription;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Searches for each target username on Instagram's Followers screen, verifies the exact
 * result row, clicks that row's remove control, confirms the dialog, and verifies that the
 * result disappeared. It deliberately stops whenever the UI cannot be identified safely.
 */
public class FollowerAccessibilityService extends AccessibilityService {
    private static final String INSTAGRAM = "com.instagram.android";

    private static final int IDLE = 0;
    private static final int WAIT_SEARCH_RESULT = 1;
    private static final int WAIT_CONFIRMATION = 2;
    private static final int WAIT_REMOVAL_RESULT = 3;
    private static final int MODE_TARGET_LIST = 1;
    private static final int MODE_NON_FOLLOWBACK = 2;

    private static final long SEARCH_TIMEOUT_MS = 15000L;
    private static final long CONFIRM_TIMEOUT_MS = 10000L;
    private static final long REMOVE_TIMEOUT_MS = 15000L;
    private static final int ACTIONS_BETWEEN_BREAKS = 100;
    private static final long BREAK_DURATION_MS = 120000L;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final List<String> targetOrder = new ArrayList<>();
    private final Set<String> targets = new HashSet<>();

    private int phase = IDLE;
    private String currentUsername = "";
    private long phaseStartedAt = 0L;
    private boolean scheduled = false;
    private int missingResultObservations = 0;
    private int actionsSinceBreak = 0;
    private int categoryScrollRetries = 0;
    private int categoryRecoveryAttempts = 0;
    private boolean categoryRecovering = false;
    private long categoryRecoveryStartedAt = 0L;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        loadTargets();
        setStatus("الخدمة جاهزة. افتح صفحة المتابعين داخل إنستغرام.");
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || event.getPackageName() == null) return;
        if (!INSTAGRAM.contentEquals(event.getPackageName())) return;
        if (!isEnabled()) return;
        scheduleProcess(650);
    }

    @Override
    public void onInterrupt() {
        stopAutomation("أوقف أندرويد خدمة إمكانية الوصول؛ أعد تفعيلها ثم ابدأ من جديد.");
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    private void loadTargets() {
        if (!targetOrder.isEmpty()) return;
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(getAssets().open("followers_2021_2022.txt")))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String username = normalizeUsername(line);
                if (!username.isEmpty() && targets.add(username)) {
                    targetOrder.add(username);
                }
            }
            if (targetOrder.isEmpty()) {
                stopAutomation("قائمة الحسابات المستهدفة فارغة.");
            }
        } catch (Exception e) {
            stopAutomation("تعذّرت قراءة قائمة أسماء المستخدمين المضمّنة.");
        }
    }

    private boolean isEnabled() {
        return getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
                .getBoolean(MainActivity.KEY_ENABLED, false);
    }

    private void scheduleProcess(long delayMs) {
        if (scheduled) return;
        scheduled = true;
        handler.postDelayed(() -> {
            scheduled = false;
            processActiveScreen();
        }, delayMs);
    }

    private void processActiveScreen() {
        if (!isEnabled()) {
            phase = IDLE;
            currentUsername = "";
            return;
        }

        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null || root.getPackageName() == null
                || !INSTAGRAM.contentEquals(root.getPackageName())) {
            return;
        }

        String screenText = collectText(root).toLowerCase(Locale.ROOT);
        if (looksLikeSecurityChallenge(screenText)) {
            stopAutomation("توقفت لحماية الحساب: ظهرت شاشة تحقق أو تحذير أمني من إنستغرام.");
            return;
        }

        int mode = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
                .getInt(MainActivity.KEY_MODE, MODE_TARGET_LIST);

        if (phase == WAIT_CONFIRMATION) {
            handleConfirmation(root, screenText);
            return;
        }
        if (phase == WAIT_REMOVAL_RESULT) {
            handleRemovalResult(root, screenText);
            return;
        }

        if (mode == MODE_NON_FOLLOWBACK) {
            if (categoryRecovering) {
                if (isNonFollowBackScreen(screenText)) {
                    categoryRecovering = false;
                    categoryScrollRetries = 0;
                    setStatus("تمت إعادة فتح التصنيف بنجاح؛ أتابع من الحسابات التي لم تُعالج بعد.");
                    processNonFollowBackScreen(root);
                } else if (screenText.contains("followers") || screenText.contains("المتابعون")
                        || screenText.contains("المتابعين")) {
                    if (clickNonFollowBackCategory(root)) {
                        setStatus("أعدت فتح تصنيف People you don't follow back بعد تحديث القائمة.");
                        scheduleProcess(1300);
                    } else if (System.currentTimeMillis() - categoryRecoveryStartedAt > 9000L) {
                        stopAutomation("رجعت إلى صفحة Followers لكن لم أتعرف على التصنيف لإعادة فتحه بأمان.");
                    } else {
                        scheduleProcess(900);
                    }
                } else if (System.currentTimeMillis() - categoryRecoveryStartedAt > 9000L) {
                    stopAutomation("تعذّرت العودة إلى صفحة Followers لإعادة فتح التصنيف.");
                } else {
                    scheduleProcess(900);
                }
                return;
            }
            if (!isNonFollowBackScreen(screenText)) {
                setStatus("افتح بنفسك تصنيف People you don't follow back داخل Followers؛ سأنتظر هذه القائمة.");
                return;
            }
            processNonFollowBackScreen(root);
            return;
        }

        if (!isFollowersScreen(screenText)) {
            setStatus("بانتظار صفحة Followers / المتابعون. افتح صفحة المتابعين واتركها ظاهرة.");
            return;
        }
        if (phase == WAIT_SEARCH_RESULT) {
            handleSearchResult(root, screenText);
            return;
        }

        beginNextSearch(root);
    }

    /** Starts the next search by replacing the search field's current value. */
    private void beginNextSearch(AccessibilityNodeInfo root) {
        String next = getNextPendingUsername();
        if (next == null) {
            stopAutomation("انتهت القائمة: لم تبقَ حسابات مستهدفة غير معالجة.");
            return;
        }

        AccessibilityNodeInfo searchField = findSearchField(root);
        if (searchField == null) {
            stopAutomation("لم أتعرف بأمان على خانة Search username or display name. لم أضغط على أي حساب.");
            return;
        }

        currentUsername = next;
        setCurrent(currentUsername);
        if (!setSearchText(searchField, currentUsername)) {
            stopAutomation("وجدت خانة البحث، لكن تعذّر إدخال @" + currentUsername + " فيها. لم أتابع.");
            return;
        }

        phase = WAIT_SEARCH_RESULT;
        phaseStartedAt = System.currentTimeMillis();
        setStatus("أبحث عن @" + currentUsername + " وأنتظر نتيجة مطابقة تماماً...");
        scheduleProcess(1300);
    }

    private void handleSearchResult(AccessibilityNodeInfo root, String text) {
        AccessibilityNodeInfo usernameNode = findExactUsernameNode(root, currentUsername);
        if (usernameNode != null) {
            Rect usernameBounds = new Rect();
            usernameNode.getBoundsInScreen(usernameBounds);
            AccessibilityNodeInfo removeControl = findRemoveControlForRow(root, usernameNode, usernameBounds);
            if (removeControl == null) {
                stopAutomation("ظهرت نتيجة @" + currentUsername
                        + "، لكن لم أستطع تحديد علامة × الخاصة بصفّها بأمان. لم أضغط على عنصر آخر.");
                return;
            }
            if (!safeClick(removeControl)) {
                stopAutomation("تعذّر الضغط على علامة × بجانب @" + currentUsername + ".");
                return;
            }
            phase = WAIT_CONFIRMATION;
            phaseStartedAt = System.currentTimeMillis();
            setStatus("تم تحديد نتيجة @" + currentUsername + " المطابقة؛ أنتظر نافذة تأكيد Remove follower.");
            scheduleProcess(900);
            return;
        }

        if (isNoResultsMessage(text)) {
            skipMissingAccount(root, "لم يعثر Instagram على نتيجة لهذا الاسم.");
            return;
        }

        if (System.currentTimeMillis() - phaseStartedAt > SEARCH_TIMEOUT_MS) {
            // Instagram sometimes exposes an empty result state without readable
            // "No results" text. After the full search timeout, skip this username
            // instead of stopping the entire run. No removal action is attempted.
            skipMissingAccount(root,
                    "انتهت مهلة البحث دون ظهور حساب مطابق؛ تم تخطي الاسم دون محاولة حذفه.");
            return;
        }
        scheduleProcess(900);
    }


    /** Marks the current target as missing and advances to the next pending username. */
    private void skipMissingAccount(AccessibilityNodeInfo root, String reason) {
        if (currentUsername == null || currentUsername.isEmpty()) {
            stopAutomation("تعذّر تحديد الحساب الحالي أثناء التخطي؛ أوقفت العملية بأمان.");
            return;
        }

        String skipped = currentUsername;
        recordMissing(skipped);
        currentUsername = "";
        setCurrent("");
        phase = IDLE;
        clearSearchField(root);
        setStatus(reason + " الحساب: @" + skipped
                + ". تم تسجيله ضمن الحسابات التي تم تخطيها، والانتقال إلى الحساب التالي.");
        scheduleProcess(900);
    }

    private void handleConfirmation(AccessibilityNodeInfo root, String text) {
        if (isConfirmationDialog(text)) {
            int mode = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
                    .getInt(MainActivity.KEY_MODE, MODE_TARGET_LIST);
            if (mode == MODE_NON_FOLLOWBACK && !text.contains(currentUsername.toLowerCase(Locale.ROOT))) {
                stopAutomation("ظهرت نافذة تأكيد، لكن اسم الحساب داخلها لا يطابق @" + currentUsername + ". لم أؤكد الإزالة.");
                return;
            }
            AccessibilityNodeInfo confirm = findConfirmationAction(root);
            if (confirm == null || !safeClick(confirm)) {
                stopAutomation("ظهرت نافذة تأكيد إزالة @" + currentUsername
                        + "، لكن لم أتعرف على زر التأكيد بدقة. لم أتابع.");
                return;
            }
            phase = WAIT_REMOVAL_RESULT;
            phaseStartedAt = System.currentTimeMillis();
            missingResultObservations = 0;
            setStatus("ضغطت تأكيد إزالة @" + currentUsername + "؛ أتحقق من اختفاء نتيجة البحث.");
            scheduleProcess(1800);
            return;
        }

        if (System.currentTimeMillis() - phaseStartedAt > CONFIRM_TIMEOUT_MS) {
            stopAutomation("لم تظهر نافذة تأكيد الإزالة المتوقعة للحساب @" + currentUsername
                    + ". أوقفت العمل دون إجراء إضافي.");
            return;
        }
        scheduleProcess(800);
    }

    private void handleRemovalResult(AccessibilityNodeInfo root, String text) {
        if (isConfirmationDialog(text)) {
            if (System.currentTimeMillis() - phaseStartedAt > CONFIRM_TIMEOUT_MS) {
                stopAutomation("بقيت نافذة التأكيد ظاهرة بعد الضغط؛ أوقفت العمل.");
            } else {
                scheduleProcess(900);
            }
            return;
        }

        AccessibilityNodeInfo remainingResult = findExactUsernameNode(root, currentUsername);
        if (remainingResult == null || isNoResultsMessage(text)) {
            missingResultObservations++;
            if (missingResultObservations >= 2) {
                String removed = currentUsername;
                int mode = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
                        .getInt(MainActivity.KEY_MODE, MODE_TARGET_LIST);
                if (mode == MODE_NON_FOLLOWBACK && !targets.contains(removed)) {
                    recordCategoryDone(removed);
                } else {
                    // Shared completion set: category-mode removals that belong to the
                    // imported 2021–2022 list are automatically excluded from that mode.
                    recordDone(removed);
                }
                currentUsername = "";
                setCurrent("");
                phase = IDLE;
                actionsSinceBreak++;
                if (mode == MODE_TARGET_LIST) clearSearchField(root);
                int totalDone = getDoneSet().size();
                if (mode == MODE_NON_FOLLOWBACK) {
                    setStatus("تم التحقق من إزالة @" + removed + " من تصنيف عدم المتابعة العكسية. سأتفقد القائمة من جديد.");
                } else {
                    setStatus("تم التحقق من اختفاء @" + removed + ". الإجمالي المؤكد: "
                            + totalDone + " من " + targetOrder.size() + ".");
                }
                if (actionsSinceBreak >= ACTIONS_BETWEEN_BREAKS) {
                    actionsSinceBreak = 0;
                    setStatus("اكتملت 100 عملية حذف مؤكدة. استراحة احترازية لمدة دقيقتين، ثم أتابع من حيث توقفت.");
                    scheduleProcess(BREAK_DURATION_MS);
                } else {
                    scheduleProcess(1400);
                }
                return;
            }
        } else {
            missingResultObservations = 0;
        }

        if (System.currentTimeMillis() - phaseStartedAt > REMOVE_TIMEOUT_MS) {
            stopAutomation("لم أستطع التحقق من اختفاء @" + currentUsername
                    + " بعد التأكيد. أوقفت العمل ولم أسجله كمحذوف.");
            return;
        }
        scheduleProcess(1000);
    }

    private boolean isNonFollowBackScreen(String text) {
        String normalized = text.replace("’", "'").replace("‘", "'");
        return normalized.contains("people you don't follow back")
                || normalized.contains("people you don’t follow back");
    }

    /**
     * Category mode: user opens this Instagram category manually. The service reads one
     * visible row at a time, verifies its username, clicks that row's X, confirms only when
     * the dialog names the same account, then re-reads the refreshed list.
     */
    private void processNonFollowBackScreen(AccessibilityNodeInfo root) {
        RowCandidate candidate = findFirstUnprocessedCategoryRow(root);
        if (candidate == null) {
            if (categoryScrollRetries >= 3) {
                beginCategoryRecovery();
                return;
            }
            if (scrollCategoryList(root)) {
                categoryScrollRetries++;
                setStatus("أمرّر قائمة People you don't follow back للبحث عن حسابات جديدة (محاولة " + categoryScrollRetries + "/3).");
                scheduleProcess(1600);
            } else {
                stopAutomation("تعذّر تمرير تصنيف People you don't follow back. لم أضغط على أي عنصر غير مؤكد.");
            }
            return;
        }

        categoryScrollRetries = 0;
        currentUsername = candidate.username;
        setCurrent(currentUsername);
        if (!safeClick(candidate.removeControl)) {
            stopAutomation("تعذّر الضغط على علامة × الخاصة بـ @" + currentUsername + ".");
            return;
        }
        phase = WAIT_CONFIRMATION;
        phaseStartedAt = System.currentTimeMillis();
        setStatus("تم تحديد علامة × بجانب @" + currentUsername + "؛ أنتظر نافذة Remove follower للتحقق من الاسم قبل التأكيد.");
        scheduleProcess(900);
    }

    private void beginCategoryRecovery() {
        if (categoryRecoveryAttempts >= 2) {
            stopAutomation("حاولت تحديث التصنيف وإعادة فتحه مرتين دون العثور على حسابات جديدة. أوقفت العمل بأمان.");
            return;
        }
        categoryRecoveryAttempts++;
        categoryRecovering = true;
        categoryRecoveryStartedAt = System.currentTimeMillis();
        categoryScrollRetries = 0;
        setStatus("حدث خلل أو لم تظهر حسابات جديدة؛ أخرج من التصنيف وأعيد فتحه تلقائياً (" + categoryRecoveryAttempts + "/2).");
        performGlobalAction(GLOBAL_ACTION_BACK);
        scheduleProcess(1100);
    }

    private boolean clickNonFollowBackCategory(AccessibilityNodeInfo root) {
        ArrayDeque<AccessibilityNodeInfo> queue = new ArrayDeque<>();
        queue.add(root);
        while (!queue.isEmpty()) {
            AccessibilityNodeInfo node = queue.removeFirst();
            CharSequence value = node.getText();
            if (value == null) value = node.getContentDescription();
            if (value != null && value.toString().toLowerCase(Locale.ROOT)
                    .replace("’", "'").contains("people you don't follow back")) {
                if (node.isClickable() && safeClick(node)) return true;
                AccessibilityNodeInfo parent = node.getParent();
                for (int i = 0; i < 4 && parent != null; i++) {
                    if (parent.isClickable() && safeClick(parent)) return true;
                    parent = parent.getParent();
                }
            }
            for (int i = 0; i < node.getChildCount(); i++) {
                AccessibilityNodeInfo child = node.getChild(i);
                if (child != null) queue.addLast(child);
            }
        }
        return false;
    }

    private static class RowCandidate {
        final String username;
        final AccessibilityNodeInfo removeControl;
        RowCandidate(String username, AccessibilityNodeInfo removeControl) {
            this.username = username;
            this.removeControl = removeControl;
        }
    }

    private RowCandidate findFirstUnprocessedCategoryRow(AccessibilityNodeInfo root) {
        ArrayDeque<AccessibilityNodeInfo> queue = new ArrayDeque<>();
        List<AccessibilityNodeInfo> nodes = new ArrayList<>();
        queue.add(root);
        while (!queue.isEmpty()) {
            AccessibilityNodeInfo node = queue.removeFirst();
            nodes.add(node);
            for (int i = 0; i < node.getChildCount(); i++) {
                AccessibilityNodeInfo child = node.getChild(i);
                if (child != null) queue.addLast(child);
            }
        }

        int width = getResources().getDisplayMetrics().widthPixels;
        int rowTolerance = dp(24);
        Set<String> done = getDoneSet();
        done.addAll(getCategoryDoneSet());

        for (AccessibilityNodeInfo followBack : nodes) {
            if (!followBack.isVisibleToUser() || !isFollowBackLabel(followBack.getText(), followBack.getContentDescription())) continue;
            Rect buttonBounds = new Rect();
            followBack.getBoundsInScreen(buttonBounds);
            if (buttonBounds.isEmpty()) continue;

            String username = null;
            int bestY = Integer.MIN_VALUE;
            for (AccessibilityNodeInfo possible : nodes) {
                if (!possible.isVisibleToUser() || possible.isEditable()) continue;
                CharSequence value = possible.getText();
                if (value == null) value = possible.getContentDescription();
                String candidate = parseUsername(value);
                if (candidate.isEmpty()) continue;
                Rect b = new Rect();
                possible.getBoundsInScreen(b);
                if (b.isEmpty() || b.centerX() >= buttonBounds.centerX()) continue;
                if (Math.abs(b.centerY() - buttonBounds.centerY()) > rowTolerance) continue;
                // The handle is normally the lower of the two text lines in the row.
                if (b.centerY() > bestY) {
                    bestY = b.centerY();
                    username = candidate;
                }
            }
            if (username == null || done.contains(username)) continue;

            AccessibilityNodeInfo xControl = null;
            int bestDistance = Integer.MAX_VALUE;
            for (AccessibilityNodeInfo possible : nodes) {
                if (!possible.isClickable() || !possible.isVisibleToUser()) continue;
                Rect b = new Rect();
                possible.getBoundsInScreen(b);
                if (b.isEmpty()) continue;
                boolean farRight = b.centerX() >= width * 0.87f;
                boolean compact = b.width() <= dp(58) && b.height() <= dp(58);
                int yDistance = Math.abs(b.centerY() - buttonBounds.centerY());
                if (farRight && compact && yDistance <= rowTolerance) {
                    int score = yDistance * 10 + Math.abs(width - b.centerX());
                    if (score < bestDistance) {
                        bestDistance = score;
                        xControl = possible;
                    }
                }
            }
            if (xControl != null) return new RowCandidate(username, xControl);
        }
        return null;
    }

    private boolean isFollowBackLabel(CharSequence text, CharSequence description) {
        return isFollowBackValue(text) || isFollowBackValue(description);
    }

    private boolean isFollowBackValue(CharSequence value) {
        if (value == null) return false;
        String s = value.toString().trim().toLowerCase(Locale.ROOT);
        return s.equals("follow back") || s.equals("متابعة") || s.equals("suivre") || s.equals("seguir");
    }

    private String parseUsername(CharSequence value) {
        if (value == null) return "";
        String s = value.toString().trim().replaceFirst("^@", "").toLowerCase(Locale.ROOT);
        if (s.contains(" ") || s.contains("\\n") || s.length() < 1 || s.length() > 30) return "";
        if (!s.matches("[a-z0-9._]+")) return "";
        return s;
    }

    private boolean scrollCategoryList(AccessibilityNodeInfo root) {
        ArrayDeque<AccessibilityNodeInfo> queue = new ArrayDeque<>();
        queue.add(root);
        while (!queue.isEmpty()) {
            AccessibilityNodeInfo node = queue.removeFirst();
            if (node.isVisibleToUser() && node.isScrollable()
                    && node.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)) return true;
            for (int i = 0; i < node.getChildCount(); i++) {
                AccessibilityNodeInfo child = node.getChild(i);
                if (child != null) queue.addLast(child);
            }
        }
        // Fallback swipe through the central list area; no account row is clicked.
        int w = getResources().getDisplayMetrics().widthPixels;
        int h = getResources().getDisplayMetrics().heightPixels;
        Path path = new Path();
        path.moveTo(w * 0.52f, h * 0.78f);
        path.lineTo(w * 0.52f, h * 0.34f);
        GestureDescription gesture = new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(path, 0, 450)).build();
        return dispatchGesture(gesture, null, null);
    }

    private String getNextPendingUsername() {
        Set<String> done = getDoneSet();
        Set<String> missing = getMissingSet();
        for (String username : targetOrder) {
            if (!done.contains(username) && !missing.contains(username)) return username;
        }
        return null;
    }

    private AccessibilityNodeInfo findSearchField(AccessibilityNodeInfo root) {
        ArrayDeque<AccessibilityNodeInfo> queue = new ArrayDeque<>();
        queue.add(root);
        AccessibilityNodeInfo best = null;
        int bestScore = Integer.MIN_VALUE;
        int screenHeight = getResources().getDisplayMetrics().heightPixels;

        while (!queue.isEmpty()) {
            AccessibilityNodeInfo node = queue.removeFirst();
            CharSequence className = node.getClassName();
            String classValue = className == null ? "" : className.toString().toLowerCase(Locale.ROOT);
            CharSequence hintValue = node.getHintText();
            String hint = hintValue == null ? "" : hintValue.toString().toLowerCase(Locale.ROOT);
            CharSequence viewIdValue = node.getViewIdResourceName();
            String viewId = viewIdValue == null ? "" : viewIdValue.toString().toLowerCase(Locale.ROOT);

            boolean editable = node.isEditable() || classValue.contains("edittext");
            boolean searchNamed = hint.contains("search") || hint.contains("username")
                    || hint.contains("بحث") || viewId.contains("search");
            if (editable && node.isVisibleToUser()) {
                Rect bounds = new Rect();
                node.getBoundsInScreen(bounds);
                int score = 0;
                if (searchNamed) score += 100;
                if (bounds.top < screenHeight * 0.45f) score += 20;
                if (bounds.width() > 0 && bounds.height() > 0) score += 5;
                if (score > bestScore) {
                    bestScore = score;
                    best = node;
                }
            }

            for (int i = 0; i < node.getChildCount(); i++) {
                AccessibilityNodeInfo child = node.getChild(i);
                if (child != null) queue.addLast(child);
            }
        }
        return best;
    }

    private boolean setSearchText(AccessibilityNodeInfo field, String value) {
        if (field == null) return false;
        field.performAction(AccessibilityNodeInfo.ACTION_CLICK);
        field.performAction(AccessibilityNodeInfo.ACTION_FOCUS);
        Bundle args = new Bundle();
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, value);
        return field.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args);
    }

    private boolean clearSearchField(AccessibilityNodeInfo root) {
        AccessibilityNodeInfo field = findSearchField(root);
        return field != null && setSearchText(field, "");
    }

    private AccessibilityNodeInfo findExactUsernameNode(AccessibilityNodeInfo root, String username) {
        if (root == null || username == null || username.isEmpty()) return null;
        ArrayDeque<AccessibilityNodeInfo> queue = new ArrayDeque<>();
        queue.add(root);
        while (!queue.isEmpty()) {
            AccessibilityNodeInfo node = queue.removeFirst();
            if (!node.isEditable() && node.isVisibleToUser()
                    && (isExactUsernameValue(node.getText(), username)
                    || isExactUsernameValue(node.getContentDescription(), username))) {
                Rect bounds = new Rect();
                node.getBoundsInScreen(bounds);
                if (!bounds.isEmpty()) return node;
            }
            for (int i = 0; i < node.getChildCount(); i++) {
                AccessibilityNodeInfo child = node.getChild(i);
                if (child != null) queue.addLast(child);
            }
        }
        return null;
    }

    private boolean isExactUsernameValue(CharSequence value, String username) {
        if (value == null) return false;
        String raw = value.toString().trim().toLowerCase(Locale.ROOT).replaceFirst("^@", "");
        if (raw.equals(username)) return true;
        String[] lines = raw.split("[\\r\\n\\s]+", 3);
        return lines.length > 0 && lines[0].replaceFirst("^@", "").equals(username);
    }

    /**
     * Prefer an explicitly labelled Remove follower control. If Instagram exposes only an
     * unlabeled X icon, accept only a small clickable control at the far-right of the exact
     * result row's vertical band. Never click a broad row or the Message button.
     */
    private AccessibilityNodeInfo findRemoveControlForRow(
            AccessibilityNodeInfo root, AccessibilityNodeInfo usernameNode, Rect usernameBounds) {
        ArrayDeque<AccessibilityNodeInfo> queue = new ArrayDeque<>();
        queue.add(root);
        AccessibilityNodeInfo labelled = null;
        AccessibilityNodeInfo rightmostX = null;
        int bestLabelScore = Integer.MAX_VALUE;
        int bestXScore = Integer.MAX_VALUE;

        int screenWidth = getResources().getDisplayMetrics().widthPixels;
        int rowTolerance = dp(48);
        int maxControlSize = dp(110);

        while (!queue.isEmpty()) {
            AccessibilityNodeInfo node = queue.removeFirst();
            if (node.isClickable() && node.isVisibleToUser()) {
                Rect bounds = new Rect();
                node.getBoundsInScreen(bounds);
                if (!bounds.isEmpty()) {
                    int yDistance = Math.abs(bounds.centerY() - usernameBounds.centerY());
                    boolean sameRow = yDistance <= rowTolerance;
                    boolean rightOfUsername = bounds.centerX() > usernameBounds.centerX() + dp(55);
                    boolean compact = bounds.width() <= maxControlSize && bounds.height() <= maxControlSize;

                    if (sameRow && rightOfUsername && isRemoveLabel(node.getText(), node.getContentDescription())) {
                        int score = yDistance;
                        if (score < bestLabelScore) {
                            bestLabelScore = score;
                            labelled = node;
                        }
                    }

                    boolean atFarRight = bounds.centerX() >= screenWidth * 0.78f;
                    if (sameRow && rightOfUsername && compact && atFarRight) {
                        int score = yDistance * 10 + Math.max(0, screenWidth - bounds.centerX()) / 10;
                        if (score < bestXScore) {
                            bestXScore = score;
                            rightmostX = node;
                        }
                    }
                }
            }
            for (int i = 0; i < node.getChildCount(); i++) {
                AccessibilityNodeInfo child = node.getChild(i);
                if (child != null) queue.addLast(child);
            }
        }
        return labelled != null ? labelled : rightmostX;
    }

    private boolean isRemoveLabel(CharSequence text, CharSequence description) {
        return isRemoveLabelValue(text) || isRemoveLabelValue(description);
    }

    private boolean isRemoveLabelValue(CharSequence value) {
        if (value == null) return false;
        String s = value.toString().trim().toLowerCase(Locale.ROOT);
        return s.equals("remove") || s.equals("remove follower") || s.equals("remove follower?")
                || s.startsWith("remove follower ") || s.equals("إزالة") || s.equals("حذف")
                || s.equals("إزالة المتابع") || s.equals("supprimer") || s.equals("retirer")
                || s.equals("supprimer l’abonné") || s.equals("supprimer l'abonné")
                || s.equals("retirer l’abonné");
    }

    private boolean isConfirmationDialog(String text) {
        boolean removeFollower = text.contains("remove follower")
                || text.contains("remove this follower")
                || text.contains("إزالة المتابع")
                || text.contains("supprimer l’abonné")
                || text.contains("supprimer l'abonné");
        boolean hasQuestionOrCancel = text.contains("remove follower?")
                || text.contains("are you sure") || text.contains("cancel")
                || text.contains("إلغاء") || text.contains("هل تريد إزالة")
                || text.contains("retour");
        return removeFollower && hasQuestionOrCancel;
    }

    private AccessibilityNodeInfo findConfirmationAction(AccessibilityNodeInfo root) {
        ArrayDeque<AccessibilityNodeInfo> queue = new ArrayDeque<>();
        queue.add(root);
        while (!queue.isEmpty()) {
            AccessibilityNodeInfo node = queue.removeFirst();
            if (node.isVisibleToUser()
                    && isConfirmationActionLabel(node.getText(), node.getContentDescription())) {
                if (node.isClickable()) return node;
                AccessibilityNodeInfo parent = node.getParent();
                for (int level = 0; level < 2 && parent != null; level++) {
                    if (parent.isClickable() && parent.isVisibleToUser()) return parent;
                    parent = parent.getParent();
                }
            }
            for (int i = 0; i < node.getChildCount(); i++) {
                AccessibilityNodeInfo child = node.getChild(i);
                if (child != null) queue.addLast(child);
            }
        }
        return null;
    }

    private boolean isConfirmationActionLabel(CharSequence text, CharSequence description) {
        return isConfirmationActionValue(text) || isConfirmationActionValue(description);
    }

    private boolean isConfirmationActionValue(CharSequence value) {
        if (value == null) return false;
        String s = value.toString().trim().toLowerCase(Locale.ROOT);
        return s.equals("remove") || s.equals("إزالة") || s.equals("حذف")
                || s.equals("supprimer") || s.equals("retirer");
    }

    private boolean isNoResultsMessage(String text) {
        return text.contains("no results") || text.contains("no users found")
                || text.contains("no people found") || text.contains("لم يتم العثور على نتائج")
                || text.contains("لا توجد نتائج") || text.contains("لم يتم العثور على أي")
                || text.contains("aucun résultat") || text.contains("aucun resultat")
                || text.contains("sin resultados");
    }

    private boolean isFollowersScreen(String text) {
        return text.contains("followers") || text.contains("المتابعون")
                || text.contains("المتابعين") || text.contains("abonnés")
                || text.contains("abonnees") || text.contains("seguidores");
    }

    private boolean looksLikeSecurityChallenge(String text) {
        return text.contains("captcha") || text.contains("challenge")
                || text.contains("suspicious activity") || text.contains("unusual activity")
                || text.contains("confirm it's you") || text.contains("confirm your account")
                || text.contains("try again later") || text.contains("we restrict certain activity")
                || text.contains("too many requests") || text.contains("نشاط غير معتاد")
                || text.contains("أكد هويتك") || text.contains("تحقق من هويتك")
                || text.contains("نشاط مريب") || text.contains("activité suspecte")
                || text.contains("confirmez votre identité");
    }

    private String collectText(AccessibilityNodeInfo root) {
        StringBuilder builder = new StringBuilder();
        ArrayDeque<AccessibilityNodeInfo> queue = new ArrayDeque<>();
        queue.add(root);
        int visited = 0;
        while (!queue.isEmpty() && visited < 4000) {
            AccessibilityNodeInfo node = queue.removeFirst();
            visited++;
            if (node.getText() != null) builder.append(node.getText()).append(' ');
            if (node.getContentDescription() != null) builder.append(node.getContentDescription()).append(' ');
            if (node.getHintText() != null) builder.append(node.getHintText()).append(' ');
            for (int i = 0; i < node.getChildCount(); i++) {
                AccessibilityNodeInfo child = node.getChild(i);
                if (child != null) queue.addLast(child);
            }
        }
        return builder.toString();
    }

    private boolean safeClick(AccessibilityNodeInfo node) {
        return node != null && node.isClickable()
                && node.performAction(AccessibilityNodeInfo.ACTION_CLICK);
    }

    private void recordDone(String username) {
        Set<String> done = getDoneSet();
        done.add(username);
        getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).edit()
                .putStringSet(MainActivity.KEY_DONE, done).apply();
    }

    private void recordMissing(String username) {
        Set<String> missing = getMissingSet();
        missing.add(username);
        getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).edit()
                .putStringSet(MainActivity.KEY_MISSING, missing).apply();
    }

    private void recordCategoryDone(String username) {
        Set<String> done = getCategoryDoneSet();
        done.add(username);
        getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).edit()
                .putStringSet(MainActivity.KEY_CATEGORY_DONE, done).apply();
    }

    private Set<String> getCategoryDoneSet() {
        Set<String> current = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
                .getStringSet(MainActivity.KEY_CATEGORY_DONE, new HashSet<>());
        return new HashSet<>(current == null ? new HashSet<>() : current);
    }

    private Set<String> getDoneSet() {
        Set<String> current = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
                .getStringSet(MainActivity.KEY_DONE, new HashSet<>());
        return new HashSet<>(current == null ? new HashSet<>() : current);
    }

    private Set<String> getMissingSet() {
        Set<String> current = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
                .getStringSet(MainActivity.KEY_MISSING, new HashSet<>());
        return new HashSet<>(current == null ? new HashSet<>() : current);
    }

    private void setCurrent(String username) {
        getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).edit()
                .putString(MainActivity.KEY_CURRENT, username).apply();
    }

    private void setStatus(String status) {
        getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).edit()
                .putString(MainActivity.KEY_STATUS, status).apply();
    }

    private void stopAutomation(String reason) {
        getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).edit()
                .putBoolean(MainActivity.KEY_ENABLED, false)
                .putString(MainActivity.KEY_STATUS, reason)
                .apply();
        phase = IDLE;
        currentUsername = "";
        setCurrent("");
        scheduled = false;
        handler.removeCallbacksAndMessages(null);
    }

    private String normalizeUsername(String value) {
        if (value == null) return "";
        return value.trim().replaceFirst("^@", "").toLowerCase(Locale.ROOT);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
