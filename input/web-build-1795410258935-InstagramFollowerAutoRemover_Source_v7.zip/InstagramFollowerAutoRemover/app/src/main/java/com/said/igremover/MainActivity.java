package com.said.igremover;

import android.accessibilityservice.AccessibilityServiceInfo;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.accessibility.AccessibilityManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.List;

public class MainActivity extends Activity {
    static final String PREFS = "igremover_prefs";
    static final String KEY_ENABLED = "enabled";
    static final String KEY_DONE = "done_usernames";
    static final String KEY_MISSING = "missing_usernames";
    static final String KEY_STATUS = "status";
    static final String KEY_CURRENT = "current_username";
    static final String KEY_MODE = "automation_mode";
    static final String KEY_CATEGORY_DONE = "category_done_usernames";
    static final String KEY_PAUSED = "automation_paused";
    static final String KEY_PHASE = "automation_phase";
    static final String KEY_ACTIONS_SINCE_BREAK = "actions_since_break";
    static final String KEY_BREAK_UNTIL = "break_until_epoch_ms";
    static final String ACTION_RESUME_AUTOMATION = "com.said.igremover.ACTION_RESUME_AUTOMATION";

    private final Handler uiHandler = new Handler();
    private TextView statusView;
    private TextView countsView;
    private Button startButton;
    private Button categoryButton;
    private int cachedTotal = -1;
    private Runnable refreshRunnable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
        requestNotificationPermissionIfNeeded();
        refreshRunnable = new Runnable() {
            @Override public void run() {
                refreshStats();
                uiHandler.postDelayed(this, 1800);
            }
        };
    }

    @Override protected void onResume() {
        super.onResume();
        uiHandler.removeCallbacks(refreshRunnable);
        uiHandler.post(refreshRunnable);
    }

    @Override protected void onPause() {
        uiHandler.removeCallbacks(refreshRunnable);
        super.onPause();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(24), dp(20), dp(24));
        root.setBackgroundColor(Color.rgb(11, 18, 32));
        scroll.addView(root);

        TextView title = text("مساعد إزالة متابعي إنستغرام", 24, true, Color.WHITE);
        root.addView(title, margin(-1, -2, 0, 10, 0, 0));
        TextView subtitle = text("أتمتة محلية على هاتفك — الحسابات المستهدفة فقط من قائمتك المستخرجة لعامَي 2021 و2022.", 14, false, Color.rgb(174, 188, 211));
        root.addView(subtitle, margin(-1, -2, 0, 0, 0, 18));

        LinearLayout statsCard = card(root);
        TextView cardTitle = text("القائمة المضمّنة", 16, true, Color.WHITE);
        statsCard.addView(cardTitle);
        countsView = text("جارٍ قراءة القائمة...", 18, true, Color.rgb(112, 215, 181));
        countsView.setPadding(0, dp(8), 0, dp(4));
        statsCard.addView(countsView);
        TextView foot = text("تطابق اسم المستخدم حرفياً قبل محاولة الحذف.", 12, false, Color.rgb(153, 168, 191));
        statsCard.addView(foot);

        LinearLayout statusCard = card(root);
        statusCard.addView(text("حالة التشغيل", 16, true, Color.WHITE));
        statusView = text("متوقف", 14, false, Color.rgb(174, 188, 211));
        statusView.setPadding(0, dp(8), 0, dp(2));
        statusCard.addView(statusView);

        Button accessibility = button("1 — تفعيل صلاحية إمكانية الوصول", false);
        root.addView(accessibility, margin(-1, 52, 0, 14, 0, 0));
        accessibility.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));

        startButton = button("2 — حذف قائمة 2021–2022", true);
        root.addView(startButton, margin(-1, 54, 0, 10, 0, 0));
        startButton.setOnClickListener(v -> startAutomation(1));

        categoryButton = button("3 — حذف People you don't follow back", true);
        root.addView(categoryButton, margin(-1, 54, 0, 10, 0, 0));
        categoryButton.setOnClickListener(v -> startAutomation(2));

        Button stop = button("إيقاف فوري", false);
        stop.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(110, 39, 53)));
        root.addView(stop, margin(-1, 50, 0, 10, 0, 0));
        stop.setOnClickListener(v -> {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .putBoolean(KEY_ENABLED, false)
                    .putBoolean(KEY_PAUSED, false)
                    .putString(KEY_CURRENT, "")
                    .putInt(KEY_PHASE, 0)
                    .putString(KEY_STATUS, "أوقفته يدوياً.")
                    .apply();
            sendBroadcast(new Intent(ACTION_RESUME_AUTOMATION).setPackage(getPackageName()));
            AutomationForegroundService.stop(this);
            refreshStats();
        });

        LinearLayout how = card(root);
        how.addView(text("طريقة الاستخدام", 16, true, Color.WHITE));
        how.addView(text(
                "1. فعّل خدمة إمكانية الوصول لهذا التطبيق من إعدادات أندرويد.\n" +
                "2. اختر حذف قائمة 2021–2022، أو اختر وضع People you don't follow back.\n" +
                "3. في وضع القائمة الثانية، افتح بنفسك تصنيف People you don't follow back داخل Instagram واتركه ظاهراً.\n" +
                "4. في الوضع الثاني يقرأ التطبيق اسم الحساب في كل صف، ويضغط × لذلك الصف، ولا يؤكد إلا إذا احتوت نافذة التأكيد على اسم الحساب نفسه.\n" +
                "5. كل حساب تتم إزالته بنجاح في الوضع الثاني يُسجّل ضمن المحذوفة المشتركة، فيُستبعد أيضاً من قائمة 2021–2022 عند تشغيلها لاحقاً.\n" +
                "6. يعيد قراءة القائمة بعد كل إزالة، ويتوقف إذا تعذّر تحديد الصف أو نافذة التأكيد بأمان. استخدم «إيقاف فوري» لإيقافه في أي لحظة.",
                14, false, Color.rgb(202, 213, 231)));

        LinearLayout caution = card(root);
        android.graphics.drawable.GradientDrawable warningBackground = new android.graphics.drawable.GradientDrawable();
        warningBackground.setColor(Color.rgb(49, 37, 25));
        warningBackground.setCornerRadius(dp(14));
        caution.setBackground(warningBackground);
        caution.addView(text("مهم جداً", 15, true, Color.rgb(255, 207, 131)));
        caution.addView(text(
                "هذه أتمتة لواجهة التطبيق وليست واجهة رسمية من Meta. قد تتوقف إذا تغيّر تصميم إنستغرام أو لم تظهر عناصره لقارئ إمكانية الوصول. تتوقف عند CAPTCHA أو تحذير أمني أو عند عدم التأكد من زر Remove. لا تدخل كلمة مرورك في هذا التطبيق؛ ولا يستطيع تجاوز التحقق الأمني. إزالة المتابعين إجراء جماعي يصعب التراجع عنه.",
                13, false, Color.rgb(231, 213, 187)));

        setContentView(scroll);
        refreshStats();
    }

    private void startAutomation(int mode) {
        if (!isServiceEnabled()) {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .putString(KEY_STATUS, "فعّل صلاحية إمكانية الوصول أولاً.").apply();
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            refreshStats();
            return;
        }
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putBoolean(KEY_ENABLED, true)
                .putBoolean(KEY_PAUSED, false)
                .putString(KEY_CURRENT, "")
                .putInt(KEY_PHASE, 0)
                .putInt(KEY_MODE, mode)
                .putString(KEY_STATUS, mode == 2
                        ? "نشط. افتح تصنيف People you don't follow back بنفسك داخل Instagram."
                        : "نشط. افتح صفحة Followers في إنستغرام.")
                .apply();
        AutomationForegroundService.start(this);
        Intent instagram = getPackageManager().getLaunchIntentForPackage("com.instagram.android");
        if (instagram != null) {
            instagram.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(instagram);
        } else {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .putString(KEY_STATUS, "لم أجد تطبيق Instagram الرسمي على هذا الهاتف.").apply();
        }
        refreshStats();
    }

    private void requestNotificationPermissionIfNeeded() {
        if (android.os.Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)
                != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 7001);
        }
    }

    private boolean isServiceEnabled() {
        AccessibilityManager manager = (AccessibilityManager) getSystemService(Context.ACCESSIBILITY_SERVICE);
        if (manager == null) return false;
        List<AccessibilityServiceInfo> enabled = manager.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK);
        for (AccessibilityServiceInfo info : enabled) {
            if (info.getResolveInfo() != null && info.getResolveInfo().serviceInfo != null) {
                String className = info.getResolveInfo().serviceInfo.name;
                if (className != null && className.equals(FollowerAccessibilityService.class.getName())) return true;
            }
        }
        return false;
    }

    private void refreshStats() {
        if (cachedTotal < 0) cachedTotal = readTotal();
        int total = cachedTotal;
        java.util.Set<String> done = getSharedPreferences(PREFS, MODE_PRIVATE).getStringSet(KEY_DONE, java.util.Collections.emptySet());
        java.util.Set<String> missing = getSharedPreferences(PREFS, MODE_PRIVATE).getStringSet(KEY_MISSING, java.util.Collections.emptySet());
        boolean enabled = getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean(KEY_ENABLED, false);
        boolean paused = getSharedPreferences(PREFS, MODE_PRIVATE).getBoolean(KEY_PAUSED, false);
        String status = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_STATUS, "لم يبدأ بعد.");
        if (countsView != null) {
            countsView.setText("" + total + " حساباً مستهدفاً\nتمت إزالتهم: " + done.size() + "\nغير موجودين/لم يتم التعرّف عليهم: " + missing.size() + "\nالمتبقي تقريباً: " + Math.max(0, total - done.size() - missing.size()));
        }
        if (statusView != null) {
            statusView.setText((enabled ? (paused ? "⏸ متوقف مؤقتاً" : "● يعمل") : "● متوقف") + "\n" + status);
        }
        if (startButton != null) startButton.setEnabled(!enabled);
        if (categoryButton != null) categoryButton.setEnabled(!enabled);
    }

    private int readTotal() {
        int n = 0;
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(getAssets().open("followers_2021_2022.txt")))) {
            while (reader.readLine() != null) n++;
        } catch (Exception ignored) { }
        return n;
    }

    private LinearLayout card(LinearLayout parent) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(16), dp(14), dp(16), dp(14));
        android.graphics.drawable.GradientDrawable cardBackground = new android.graphics.drawable.GradientDrawable();
        cardBackground.setColor(Color.rgb(20, 31, 50));
        cardBackground.setCornerRadius(dp(14));
        c.setBackground(cardBackground);
        parent.addView(c, margin(-1, -2, 0, 12, 0, 0));
        return c;
    }

    private TextView text(String value, int sp, boolean bold, int color) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setGravity(Gravity.START);
        t.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
        t.setLineSpacing(dp(3), 1.0f);
        return t;
    }

    private Button button(String label, boolean primary) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(15);
        b.setTextColor(Color.WHITE);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(primary ? Color.rgb(79, 117, 225) : Color.rgb(39, 57, 84)));
        return b;
    }

    private LinearLayout.LayoutParams margin(int width, int height, int left, int top, int right, int bottom) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(width < 0 ? width : dp(width), height < 0 ? height : dp(height));
        lp.setMargins(dp(left), dp(top), dp(right), dp(bottom));
        return lp;
    }

    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }
}
